class Exercise:
    """A Exercise class"""

    def __init__(self,exercise_name, category, exercise_description, teacher_id):
        self.exercise_name=exercise_name
        self.category=category
        self.exercise_description=exercise_description
        self.teacher_id=teacher_id
