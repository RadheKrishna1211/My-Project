import tkinter as tk
import student_menu.add_student as addstd
import student_menu.edit_delete_student as edstd
import quiz_menu.add_exercise as ex
import quiz_menu.edit_delete_exercise as ed
import quiz_menu.add_quiz_question as aq
import quiz_menu.select_exercise_for_edit_delete as sed
import quiz_menu.assign_quiz as asnq
import quiz_menu.unassign_quiz as uq

class TeacherMenuBar:
    def __init__(self, master,teacher_id):
        self.teacher_id=teacher_id
        self.master = master
        self.master.title("Inclusive Scan and Play Software")
        self.master.state('zoomed')#automatically expands window to full size
        
        self.master.configure(bg='cyan4')
        self.master.rowconfigure(0, weight=1)
        self.master.columnconfigure(0, weight=1)
        self.main_menu = tk.Menu(self.master)
        self.master.config(menu=self.main_menu)
        self.main_menu.add_command(label="My Profile", command=self.profile_command)

        student_commands = {"Add Students": self.add_student_command, "Edit/Delete Students": self.edit_delete_student_command,"View Student Results":self.view_results_student_command}
        self.create_submenu(self.main_menu, "Manage Students", student_commands)

        quiz_commands = {"Add Exercises": self.add_exercise_command,"Edit/Delete Exercises":self.edit_delete_exercise_command,"Add Quizzes to Exercises": self.add_quiz_questions_command, "Edit/Delete Quizzes": self.edit_delete_quiz_command}
        self.create_submenu(self.main_menu, "Manage Games/Quizzes", quiz_commands)

        assign_commands = {"Assign Quizzes to Students": self.assign_quizzes_command,"Unassign Quizzes to Students":self.unassign_quizzes_command}
        self.create_submenu(self.main_menu, "Assign/Unassign Quizzes", assign_commands)

        self.main_menu.add_command(label="Logout", command=self.logout_command)
        
        self.header_frame=tk.Frame(self.master,background="cyan4")
        self.header_frame.grid()
        self.display_frame=tk.Frame(self.master,background="cyan4")
        self.display_frame.grid()

    def create_submenu(self,parent_menu, label, commands):
        submenu = tk.Menu(parent_menu, tearoff=0)
        for command_label, command_func in commands.items():
            submenu.add_command(label=command_label, command=command_func)
        parent_menu.add_cascade(label=label, menu=submenu)
    
    def profile_command(self):
        print("This is a Profile command.")
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def add_student_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        print("This is a add student command inside teacher menu..............")
        addstd.AddStudent(self.master,self.header_frame,self.display_frame,self.teacher_id)
       
    def edit_delete_student_command(self):
        print("This is a edit delete student command...........................")
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        edstd.EditDeleteStudent(self.master,self.header_frame,self.display_frame,self.teacher_id)
                
    def view_results_student_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        print("This is a view results student command.") 

    def add_exercise_command(self):
        print("inside add excercise ")
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        ex.AddExercise(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def edit_delete_exercise_command(self):
        print("inside add excercise ")
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        ed.EditDeleteExercise(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def add_quiz_questions_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        
        print("This is a add quiz command.")
        aq.AddQuizQuestion(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def edit_delete_quiz_command(self):
        print("This is a edit delete quiz command.")
        sed.SelectExerciseEditDelete(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def assign_quizzes_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        print("This is a Assign command.")
        asnq.AssignQuiz(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def unassign_quizzes_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        print("This is a Un Assign command.")
        uq.UnassignQuiz(self.master,self.header_frame,self.display_frame,self.teacher_id)

    def logout_command(self):
        #print("This is a logout command.")
        self.master.destroy()

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    


