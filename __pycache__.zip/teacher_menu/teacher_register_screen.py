import tkinter as tk
from tkinter import messagebox
import database_code as db 
import login_screen as ls
import class_representations.teacher as teacher
import password_encryption as pe


class RegisterScreen:
    def __init__(self, master):
        self.master = master
        self.master.title("Register Teacher Screen")
        self.master.state('zoomed')#automatically expands window to full size
        self.master.title("Inclusive Scan and Play Software")
        self.master.configure(bg='cyan4')
        self.master.rowconfigure(0, weight=1)
        self.master.columnconfigure(0, weight=1)

        self.header_frame = tk.Frame(self.master,background="cyan4")
        self.header_frame.grid()

        self.display_frame = tk.Frame(self.master,background="cyan4")
        self.display_frame.grid()
        self.create_registration_screen()

    def create_registration_screen(self):
        self.lbl_register_screen = tk.Label(self.header_frame, text="Registration Page for New Teachers! ", bg='cyan4', fg='white', font=('Arial',30))
        self.lbl_register_screen.grid( row=0,column=0)

        self.lbl_first_name=tk.Label(self.display_frame,text='First Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_first_name.grid(row=1,column=0,sticky = 'W', pady = 20)

        self.lbl_last_name=tk.Label(self.display_frame,text='Last Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_last_name.grid(row=2,column=0,sticky = 'W', pady = 20)
        
        self.lbl_email=tk.Label(self.display_frame,text='email :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_email.grid(row=3,column=0,sticky = 'W', pady = 20)

        self.lbl_user_name=tk.Label(self.display_frame,text='User Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_user_name.grid(row=4,column=0,sticky = 'W', pady = 20)
        
        self.lbl_password=tk.Label(self.display_frame,text='Password :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_password.grid(row=5,column=0,sticky = 'W', pady = 20)

        self.txtbox_first_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_first_name.grid(row=1,column=2,sticky = 'W', pady = 20)

        self.txtbox_last_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_last_name.grid(row=2,column=2,sticky = 'W', pady = 20)
        
        self.txtbox_email=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_email.grid(row=3,column=2,sticky = 'W', pady = 20)

        self.txtbox_user_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_user_name.grid(row=4,column=2,sticky = 'W', pady = 20)

        self.txtbox_password=tk.Entry(self.display_frame, font=('Arial',20),show="*")
        self.txtbox_password.grid(row=5,column=2,sticky = 'W', pady = 20)

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',bg='cyan3',font=('Arial',15), command=self.cancel_command)
        self.btn_cancel.grid(row=6,column=0, pady = (20,100))

        self.btn_register=tk.Button(self.display_frame,text='Register',bg='cyan3',font=('Arial',15), command=self.register_command)
        self.btn_register.grid(row=6,column=2, sticky = 'E', pady = (20,100))
    
    def register_command(self):
        user_name=self.txtbox_user_name.get()
        password=self.txtbox_password.get()
        first_name = self.txtbox_first_name.get()
        last_name = self.txtbox_last_name.get()
        email = self.txtbox_email.get()
        teacher_object = teacher.Teacher(first_name,last_name,email,user_name,pe.encrypt_password(password))
        result = db.check_teacher_user_exists(user_name)
        if user_name=='' or password=='' or first_name=='' or last_name=='' :
            messagebox.showerror('Registration','Blanks are not allowed')
        elif  result == True:
            messagebox.showerror('Registration','User Name is already taken, select another user name')
        else:
            self.insert_user(teacher_object)
            self.show_login_screen()

    def insert_user(self,teacher_object):
        db.insert_teacher(teacher_object)

    def show_login_screen(self):
           self.clear_frame(self.display_frame)
           self.clear_frame(self.header_frame)
           ls.LoginScreen(self.master,self.header_frame,self.display_frame)
    
    def cancel_command(self):

        messagebox.askokcancel("Login Exit","Do you want to cancel?")
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        ls.LoginScreen(self.master, self.header_frame, self.display_frame)
      
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()