import tkinter as tk

class StudentMainScreen:
    def __init__(self, master, student_user_name):
        self.student_user_name = student_user_name
        self.master = master
        self.master.state('zoomed')      
        self.header_frame=tk.Frame(self.master,background="cyan4")
        self.header_frame.grid(row=0,column=0)        
        add_quiz_header_lbl = tk.Label(self.header_frame, text="Select one of the following Category!", font=('Arial', 24), bg='cyan4', fg='white')
        add_quiz_header_lbl.grid(row=1,column=0,sticky = 'W', pady = 5)
        self.display_frame=tk.Frame(self.master,background="cyan4")
        self.display_frame.grid(row=1,column=0)
        text_list=['Alphabet Scramble (Spelling)', 'Sentence Builder','Objective Type Questions','Odd One Out Image Challenge']
        
        pad_y = 30
        for i in range(0,4):
            self.btn_cat=tk.Button(self.display_frame,text=text_list[i], width=40,bg='cyan3',font=('Arial',15), command=lambda myrow=i: self.btn_actions(myrow))
            if i != 3:
                self.btn_cat.grid(row=i+2,column=3, pady =(0,pad_y))
            else:
                self.btn_cat.grid(row=i+2,column=3, pady =(0,pad_y+100))

    def btn_actions(self,row):
        if row==0:
            self.alphabet_scramble_screen()
        elif row==1:
            self.sentence_builder_screen()
            
        elif row==2:
            self.objective_type_quiz()
        else:
            self.odd_one_out_image_challenge_screen()
            
if __name__ == "__main__":
    master = tk.Tk()
    student_main_screen = StudentMainScreen(master,"Student Main Screen")
    master.mainloop()

