import tkinter as tk
import database_code as db
import class_representations.student as student
from tkinter import messagebox
from tkinter import ttk

class EditQuestionsGame3:
    def __init__(self, master,header_frame,display_frame,teacher_id,exercise_id,question_row):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        self.exercise_id = exercise_id
        self.exercise_name= db.get_exercise_name_for_id(self.exercise_id, self.teacher_id)
        self.question_row=question_row
        self.list = db.get_exercise_name_category(self.exercise_name,self.teacher_id)
        print("EDITQGAME3  returned list in edit question game 3", self.list)
        self.category = self.list[0][1]

        self.answer_option_list = [1,2,3,4]

        questions = db.check_question_game3_exists(exercise_id,teacher_id,question_row[0])
        print("EDITQGAME3  exercise fetched in editing game3")
        print(questions)
        if questions:
            print("EDITQGAME3  inside edit game3 questions")
            
            self.lbl_header=tk.Label(self.header_frame,text='Edit sentence builder questions Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 20)

            self.lbl_exercise_name=tk.Label(self.display_frame,text='Exercise Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name.grid(row=1,column=0,sticky = 'W', pady = 20)

            self.lbl_category=tk.Label(self.display_frame,text='Category :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_category.grid(row=2,column=0,sticky = 'W', pady = 20)

    
            self.lbl_exercise_name_display=tk.Label(self.display_frame,text=self.exercise_name,font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name_display.grid(row=1,column=1,sticky = 'W', pady = 20)
            print("EDITQGAME3  game3..........")
            
            self.lbl_category_display=tk.Label(self.display_frame,text=self.category,font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_category_display.grid(row=2,column=1,sticky = 'W', pady = 20)

            self.lbl_enter_question = tk.Label(self.display_frame, text='Enter a Question:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_enter_question.grid(row=3, column=0, pady=10, padx=10)
            self.txtbox_enter_question=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_enter_question.grid(row=3,column=1,sticky = 'W', pady = 20)
            self.txtbox_enter_question.insert(0,self.question_row[1])

            self.lbl_option1 = tk.Label(self.display_frame, text='Option 1', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_option1.grid(row=4, column=0, pady=10, padx=10)
            self.txtbox_option1=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_option1.grid(row=4,column=1,sticky = 'W', pady = 20)
            self.txtbox_option1.insert(0,self.question_row[2])

            self.lbl_option2 = tk.Label(self.display_frame, text='Option 2', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_option2.grid(row=4, column=2, pady=10, padx=10)
            self.txtbox_option2=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_option2.grid(row=4,column=3,sticky = 'W', pady = 20)
            self.txtbox_option2.insert(0,self.question_row[3])

            self.lbl_option3 = tk.Label(self.display_frame, text='Option 3', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_option3.grid(row=5, column=0, pady=10, padx=10)
            self.txtbox_option3=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_option3.grid(row=5,column=1,sticky = 'W', pady = 20)
            self.txtbox_option3.insert(0,self.question_row[4])

            self.lbl_option4 = tk.Label(self.display_frame, text='Option 4', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_option4.grid(row=5, column=2, pady=10, padx=10)
            self.txtbox_option4=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_option4.grid(row=5,column=3,sticky = 'W', pady = 20)
            self.txtbox_option4.insert(0,self.question_row[5])

            self.dropdown_answer = ttk.Combobox(self.display_frame, values=self.answer_option_list)
            self.dropdown_answer.grid(row=6, column=1, padx=10, pady=5, sticky="w")

            current_value = int(self.question_row[6])
            print("EDITQGAME3  game 3 current value")
            print(current_value)
            if current_value in self.answer_option_list:
                index = self.answer_option_list.index(current_value)
                print("EDITQGAME3  printing index game3",index)
                self.dropdown_answer.current(index)
            else:
                print("EDITQGAME3  Current value not found in options!")

            self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
            self.btn_cancel.grid(row=7,column=0, pady = (20,200))

            self.btn_submit=tk.Button(self.display_frame,text='Submit',bg='cyan3',font=('Arial',15), command=self.update_question_game3_data)
            self.btn_submit.grid(row=7,column=1, pady = (20,200))
        else:
            messagebox.showerror("Quiz Menu","There was an error in questions Selection!")

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def update_question_game3_data(self):
        self.obj_question = self.txtbox_enter_question.get()
        self.option1 = self.txtbox_option1.get()
        self.option2 = self.txtbox_option2.get()
        self.option3 = self.txtbox_option1.get()
        self.option4 = self.txtbox_option3.get()
        self.answer_option=self.dropdown_answer.get()

        if self.obj_question=="" and self.option1 =="" and self.option2 =="" and self.option3 =="" and self.option4 =="" and self.answer =="":
            messagebox.showinfo('Quiz Menu',"Question,options and Answer cannot  be empty")
        else:
            self.update_question(self.obj_question, self.option1, self.option2, self.option3, self.option4, self.answer_option)
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
           
    def update_question(self,obj_question, option1, option2, option3, option4, answer_option):
        db.update_question_game3(self.exercise_id,self.question_row[0], obj_question, option1, option2, option3, option4, answer_option,self.teacher_id)
        messagebox.showinfo('Quiz Menu','Questions Updated Successfully!!')
