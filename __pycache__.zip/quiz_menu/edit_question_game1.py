import tkinter as tk
import database_code as db
import class_representations.student as student
from tkinter import messagebox

class EditQuestionsGame1:
    def __init__(self, master,header_frame,display_frame,teacher_id,exercise_id,question_row):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        self.exercise_id = exercise_id
        self.exercise_name= db.get_exercise_name_for_id(self.exercise_id, self.teacher_id)
        self.question_row=question_row
       
        self.list = db.get_exercise_name_category(self.exercise_name,self.teacher_id)
        print("EDITQGAME1  returned list in edit question game 1", self.list)
        self.category = self.list[0][1]

        
        word = db.check_question_game1_exists(exercise_id,teacher_id,question_row[0])
        print("EDITQGAME1  exercise fetched in editing")
        print(word)
        if word:
            print("EDITQGAME1  inside add game1 word")
            
            self.lbl_header=tk.Label(self.header_frame,text='Edit Alphabet Scramble questions Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 20)

            self.lbl_exercise_name=tk.Label(self.display_frame,text='Exercise Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name.grid(row=1,column=0,sticky = 'W', pady = 20)

            self.lbl_category=tk.Label(self.display_frame,text='Category :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_category.grid(row=2,column=0,sticky = 'W', pady = 20)

            self.lbl_exercise_name_display=tk.Label(self.display_frame,text=self.exercise_name,font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name_display.grid(row=1,column=1,sticky = 'W', pady = 20)
            print("EDITQGAME1  first data..........")
            
            self.lbl_category_display=tk.Label(self.display_frame,text=self.category,font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_category_display.grid(row=2,column=1,sticky = 'W', pady = 20)

            self.lbl_enter_word = tk.Label(self.display_frame, text='Enter a word 2 to 6 letters:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_enter_word.grid(row=3, column=0, pady=10, padx=10)
            self.txtbox_enter_word=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_enter_word.grid(row=3,column=1,sticky = 'W', pady = 20)
            self.txtbox_enter_word.insert(0,self.question_row[1])

            self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',20),bg='cyan3',command=self.cancel_command)
            self.btn_cancel.grid(row=4,column=0, pady = (20,200))

            self.btn_submit=tk.Button(self.display_frame,text='Submit',bg='cyan3',font=('Arial',15), command=self.update_question_game1_data)
            self.btn_submit.grid(row=4,column=1, pady = (20,200))
        else:
            messagebox.showerror("Quiz Menu","There was an error in questions Selection!")

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def update_question_game1_data(self):
        self.word=self.txtbox_enter_word.get()

        if self.word=='':
            messagebox.showerror('Quiz Menu','Blanks are not allowed')
        else:
            self.update_question(self.word)
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
           
    def update_question(self,word):
        db.update_question_game1(self.exercise_id,self.question_row[0],word,self.teacher_id)
        messagebox.showinfo('Quiz Menu','Question Updated Successfully!!')
