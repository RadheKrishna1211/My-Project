import tkinter as tk
from tkinter import font
from tkinter import ttk
import database_code as db
from tkinter import messagebox
import class_representations.exercise as exercise

class AddExercise:
    def __init__(self, master, header_frame, display_frame, teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.master = master
        self.master.state('zoomed')
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.teacher_id= teacher_id
        self.categories = ["Sentence Builder", "Alphabet Scramble","Objective Type","Odd One Out Image"]

        self.lbl_heading = tk.Label(self.header_frame, text='Add Exercise', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_heading.grid(row=0, column=0, pady=10)
        self.lbl_category = tk.Label(self.display_frame, text='Category:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_category.grid(row=1, column=0, pady=10, padx=10)
        self.dropdown_category = ttk.Combobox(self.display_frame, values=self.categories,font=('Arial',20))
        self.dropdown_category.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=2, column=0, sticky='w', padx=10, pady=5)
        self.textbox_exercise_name = tk.Entry(self.display_frame, font=('Arial',20))
        self.textbox_exercise_name.grid(row=2, column=1, sticky='w', padx=10, pady=5)

        self.lbl_exercise_description = tk.Label(self.display_frame, text='Exercise Description:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_description.grid(row=3, column=0, sticky='w', padx=10, pady=5)
        self.textbox_exercise_description = tk.Entry(self.display_frame, font=('Arial',20))
        self.textbox_exercise_description.grid(row=3, column=1, sticky='w', padx=10, pady=5)

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=4,column=0, pady = (20,200))
        self.btn_Add=tk.Button(self.display_frame,text='Add',font=('Arial',15),bg='cyan3',command=self.add_exercise_screen)
        self.btn_Add.grid(row=4,column=1, pady = (20,200))
    
    def add_exercise_screen(self):
        self.exercise_name=self.textbox_exercise_name.get()
        self.category=self.dropdown_category.get()
        self.exercise_description=self.textbox_exercise_description.get()

        exercise_object = exercise.Exercise(self.exercise_name,self.category,self.exercise_description,self.teacher_id)
        result = db.check_exercise_exists(self.exercise_name, self.teacher_id)
        if self.exercise_name=='' or self.teacher_id=='':
            messagebox.showerror('Quiz Menu','Blanks are not allowed')
        elif  result == True:
            messagebox.showerror('Quiz Menu',' exercise Name is already taken, select another exercise name')
        else:
            self.insert_exercise(exercise_object)
    
    def insert_exercise(self,exercise_object):
        is_exercise_exists = db.check_exercise_exists(exercise_object.exercise_name,self.teacher_id)
        if not(is_exercise_exists):
            db.insert_exercise(exercise_object)
            messagebox.showinfo('Quiz Menu','exercise added Successfully!!')
            self.clear_frame(self.display_frame)
            self.clear_frame(self.header_frame)
        else:
           messagebox.showerror('Quiz Menu','exercise_name  Already Exists, give another exercise name!!')

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
      
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

         
    