import tkinter as tk
import database_code as db
from tkinter import messagebox
import quiz_menu.edit_question_game2 as eqg2

class EditDeleteGame2:
    def __init__(self, master,header_frame, display_frame,exercise_name,category,teacher_id):
        self.teacher_id = teacher_id
        self.master = master
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.exercise_name=exercise_name
        self.exercise_id = db.get_exercise_id(self.exercise_name,self.teacher_id)
        self.category=category
        self.checkbox_vars_edit_delete_list = []
        print("inside editdelete game2")
        
        self.questions=db.edit_delete_question_game2(self.exercise_id,self.teacher_id)
        
        if len(self.questions)!=0:
            self.lbl_header=tk.Label(self.header_frame,text='Edit / Delete Sentence Builder Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 1)
            self.create_table()
        else:
            messagebox.showerror('Quiz Menu','You havent added any Questions, please add questions to exercise!')
    
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def create_table(self):        
        column_headers = ["Q. no  ","Sentence                  ","Edit/Delete"]
        for col, header in enumerate(column_headers):
            label = tk.Label(self.display_frame, text=header, borderwidth=1, font=('Arial',20),bg='Cyan4',fg='White')
            label.grid(row=0, column=col,sticky = 'W', pady = 2)
        
        for row, data_row in enumerate(self.questions, start=1):
            print("in enumerating rows.....................")
            print("printing row number")
            print(row)
            for col, cell_value in enumerate(data_row):
                label = tk.Label(self.display_frame, text=cell_value, borderwidth=1, font=('Arial',20),bg='Cyan4',fg='White')
                label.grid(row=row, column=col,sticky = 'W', pady = 2)
            checkbox_var = tk.BooleanVar(value=False)
            checkbox = tk.Checkbutton(self.display_frame, variable=checkbox_var,command=lambda myrow=row: self.clear_other_checkboxes(myrow, self.checkbox_vars_edit_delete_list))
            checkbox.grid(row=row, column=3) 
            self.checkbox_vars_edit_delete_list.append(checkbox_var)
                      
        bottom_distance=200//(len(self.questions))

        self.btn_edit=tk.Button(self.display_frame,text='Edit',bg='cyan3',font=('Arial',15), command=self.edit_question_game2_screen)
        self.btn_edit.grid(row=len(self.questions)+1,column=1, pady = (10,bottom_distance))
        self.btn_delete=tk.Button(self.display_frame,text='Delete',bg='cyan3',font=('Arial',15), command=self.delete_question_game2_screen)
        self.btn_delete.grid(row=len(self.questions)+1,column=2, pady = (10,bottom_distance))    
        
    def edit_question_game2_screen(self):
        print("edit questions")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for deleting")
        else:
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
            print("passing the question row selected in edit delete game2", self.questions[row_selected])
            eqg2.EditQuestionsGame2(self.master,self.header_frame,self.display_frame,self.teacher_id,self.exercise_id,self.questions[row_selected])

    def delete_question_game2_screen(self):
        print("delete questions game 2 ")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for deleting")
        else:
            print(self.questions[row_selected])
            self.exercise_id = db.get_exercise_id(self.exercise_name,self.teacher_id)
            db.delete_question_game2(self.questions[row_selected][0],self.exercise_id,self.teacher_id)
            messagebox.showinfo('Quiz Menu','You have successfully deleted the questions!')
            self.clear_frame(self.display_frame)
            self.clear_frame(self.header_frame)

    def clear_other_checkboxes(self,row, checkbox_list):
        for i, checkbox in enumerate(checkbox_list):
            if i+1 != row:
                checkbox.set(False)
    