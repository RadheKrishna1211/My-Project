import tkinter as tk
from tkinter import ttk
import database_code as db
from tkinter import font

import quiz_menu.sentence_builder as sb
import quiz_menu.alphabet_scramble as ab
import quiz_menu.objective_type_exercise as oq
import quiz_menu.odd_one_out as oou
from tkinter import messagebox

class AddQuizQuestion:
    def __init__(self, master, header_frame, display_frame, teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.master.state('zoomed')
        self.teacher_id= teacher_id
        self.no_of_words = [1,2,3,4,5,6]
        self.exercise_names=db.get_exercise_names(teacher_id)
        print("exercise names are",self.exercise_names)
        if len(self.exercise_names)==0:
            messagebox.showerror('Quiz Menu','There are no Exercises to Add Quizzes to. Please create Exercises!')
        else:
            self.lbl_heading_quiz_question = tk.Label(self.header_frame, text='Add Quiz Questions:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_heading_quiz_question.grid(row=0, column=0, pady=10)
            
            self.lbl_select_exercise = tk.Label(self.display_frame, text='Select Exercise:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_select_exercise.grid(row=2, column=0, pady=10, padx=10)
            self.dropdown_select_exercise = ttk.Combobox(self.display_frame, values=self.exercise_names, font=('Arial',20))
            self.dropdown_select_exercise.grid(row=2, column=1, padx=10, pady=5, sticky="w")

            self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
            self.btn_cancel.grid(row=4,column=0, pady = (20,200))
            self.btn_add=tk.Button(self.display_frame,text='Add',font=('Arial',15),bg='cyan3',command=self.add_quiz_question_command)
            self.btn_add.grid(row=4,column=1, pady = (20,200))
        
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()
      
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        
    def add_quiz_question_command(self):
        self.exercise_name=self.dropdown_select_exercise.get()
        self.exercise_id = db.get_exercise_id(self.exercise_name,self.teacher_id)
        print("inside the add_quiz_question_command exname, exid, teachid:",self.exercise_name,self.exercise_id, self.teacher_id)
        self.exercise_name_category=db.get_exercise_name_category(self.exercise_name,self.teacher_id)
        print("inside the add_quiz_question_command - exercise name category:",self.exercise_name_category)
        print(self.exercise_name_category[0][1])
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

        if self.exercise_name_category[0][1]=="Sentence Builder":
            print("inside Sentence Builder if statement.........")
            print("data passed to sentence builder.......", self.exercise_id,self.teacher_id)
            sb.SentenceBuilder(self.master, self.header_frame, self.display_frame,self.exercise_id,self.teacher_id)
        
        elif self.exercise_name_category[0][1]=="Alphabet Scramble":
            print("Inside Alphabet Scramble if statement ")
            ab.AlphabetScramble(self.master, self.header_frame, self.display_frame,self.exercise_id,self.teacher_id)
        elif self.exercise_name_category[0][1]=="Objective Type":
            print("Objective Type")
            oq.ObjectiveQuestion(self.master, self.header_frame, self.display_frame,self.exercise_id,self.teacher_id)
        else:
            print("Odd One Out Image")
            oou.OddOneOut(self.master, self.header_frame, self.display_frame,self.exercise_id,self.teacher_id)
