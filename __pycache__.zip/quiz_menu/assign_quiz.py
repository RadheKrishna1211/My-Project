import tkinter as tk
from tkinter import ttk
from tkinter import font
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox

class AssignQuiz:
    def __init__(self, master,header_frame,display_frame,teacher_id):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.categories = ["Sentence Builder", "Alphabet Scramble","Objective Type","Odd One Out Image"]
        self.exercise_names=[]
        self.students_list=[]

      ###########################################################
        self.header_frame=tk.Frame(self.master,background="cyan4")
        self.header_frame.grid(row=0,column=0)        
        assign_quiz_header_lbl = tk.Label(self.header_frame, text="Assign Unassign Quiz screen", font=('Arial', 24), bg='cyan4', fg='white')
        assign_quiz_header_lbl.grid(row=1,column=0,sticky = 'W', pady = 5)
        
        self.display_frame=tk.Frame(self.master,background="cyan4")
        self.display_frame.grid(row=1,column=0)

        self.lbl_category=tk.Label(self.display_frame,text='Category :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_category.grid(row=2,column=0,sticky = 'W', pady = 20)
        self.dropdown_category = ttk.Combobox(self.display_frame, values=self.categories, font=('Arial',20))
        self.dropdown_category.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        self.dropdown_category.bind("<<ComboboxSelected>>", self.update_exercise_based_on_category)

        self.lbl_exercise_name=tk.Label(self.display_frame,text='Exercise Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=3,column=0,sticky = 'W', pady = 20)
        self.dropdown_exercise_name = ttk.Combobox(self.display_frame, values=self.exercise_names, font=('Arial',20))
        self.dropdown_exercise_name.grid(row=3, column=1, padx=10, pady=5, sticky="w")
        self.dropdown_exercise_name.bind("<<ComboboxSelected>>", self.update_students_based_on_exercise)

        self.lbl_student_user_name=tk.Label(self.display_frame,text='Student User Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_student_user_name.grid(row=4,column=0,sticky = 'W', pady = 20)
        self.dropdown_student_user_name = ttk.Combobox(self.display_frame, values=self.students_list,font=('Arial',20))
        self.dropdown_student_user_name.grid(row=4, column=1, padx=10, pady=5, sticky="w")

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=5,column=0, pady = (20,200))
        self.btn_assign=tk.Button(self.display_frame,text='Assign',font=('Arial',15),bg='cyan3', command=self.assign_quiz_command)
        self.btn_assign.grid(row=5,column=2, pady = (20,200))

    def update_exercise_based_on_category(self,event):
        #abc = event.widget.get()
        category= self.dropdown_category.get()
        exercise_list = db.get_exercise_for_category(category, self.teacher_id)
        if exercise_list[0] == None:
            messagebox.showerror("Quiz Menu", "There are no exercises for this category")
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
        else:
            self.dropdown_exercise_name.config(values=exercise_list[0])
    
    def update_students_based_on_exercise(self, event):
        exercise_name = self.dropdown_exercise_name.get()
        exercise_id=db.get_exercise_id(exercise_name,self.teacher_id)
        #get the students who are not assigned to the particular exercise selected
        student_list = db.get_unassigned_student_list_for_exercise( exercise_id,self.teacher_id)
        print("inside update students based on exercise", student_list)
        self.dropdown_student_user_name.config(values=student_list)

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()
            
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
    
    def assign_quiz_command(self):
        
        print("Assign Quiz button ")
        exercise_name = self.dropdown_exercise_name.get()
        student_user_name = self.dropdown_student_user_name.get()
        self.exercise_id = db.get_exercise_id(exercise_name, self.teacher_id)
        self.student_id = db.get_student_id(student_user_name, self.teacher_id)
        flag = db.insert_assign_quiz(self.exercise_id,self.student_id)
        if flag==1:
            messagebox.showinfo("Quiz Menu", "Exercise Assigned to Student Successfully")
        else:
           messagebox.showerror("Quiz Menu", "Exercise already assigned to Student") 
        self.cancel_command()
        

