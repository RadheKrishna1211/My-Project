category = ["SB","AS","Opj","Odd"]

category_combo = ttk.Combobox(root, width=37, value=(category))
category_combo.grid(row=3, column=1, columnspan=2, padx=10, pady=2, sticky='w')

def callback(eventObject):
    abc = eventObject.widget.get()
    cat = category_combo.get()
    exercise_list = db.get_exercise_for_category(cat, teacher_id)
    exerr_combo.config(values=exercise_list)

exerr_combo = ttk.Combobox(root, width=37)
exerr_combo.grid(row=4, column=1, columnspan=2, padx=10, pady=2,
