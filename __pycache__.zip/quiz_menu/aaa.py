class Car:
    def __init__(self,brand_car,color_car,type_car):
        self.brand_car=brand_car
        self.color_car=color_car
        self.type_car=type_car
    def run(self):
        print("car info is: ",self.brand_car,self.color_car,self.type_car)
        
class Maruti(Car):
    def __init__(self,color_car,type_car):
        super().__init__("maruti",color_car,type_car)
        
    def run(self):
        print("car info is: ",self.brand_car,self.color_car,self.type_car)

c1 = Car("Honda","red")
m1 = Maruti("blue","4 wheels")
c1.run()
m1.run()