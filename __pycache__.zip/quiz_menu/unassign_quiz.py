import tkinter as tk
from tkinter import ttk
from tkinter import font
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox

class UnassignQuiz:
    def __init__(self, master,header_frame,display_frame,teacher_id):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.categories = ["Sentence Builder", "Alphabet Scramble","Objective Type","Odd One Out Image"]
        ##### RADHE WRITE THESE DATABASE FUNCTIONS #############
        self.exercise_names_list = db.get_exercise_for_category()  
        self.students_list = []

      ###########################################################
        self.header_frame=tk.Frame(self.master,background="cyan4")
        self.header_frame.grid(row=0,column=0)        
        assign_quiz_header_lbl = tk.Label(self.header_frame, text="Unassign Quiz screen", font=('Arial', 24), bg='cyan4', fg='white')
        assign_quiz_header_lbl.grid(row=1,column=0,sticky = 'W', pady = 5)
        
        self.display_frame=tk.Frame(self.master,background="cyan4")
        self.display_frame.grid(row=1,column=0)

        self.lbl_category=tk.Label(self.display_frame,text='Category :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_category.grid(row=2,column=0,sticky = 'W', pady = 20)
        self.dropdown_category = ttk.Combobox(self.display_frame, values=self.categories, font=('Arial',20))
        self.dropdown_category.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        self.lbl_exercise_name=tk.Label(self.display_frame,text='Exercise Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=3,column=0,sticky = 'W', pady = 20)
        self.dropdown_exercise_name = ttk.Combobox(self.display_frame, values=self.exercise_names, font=('Arial',20))
        self.dropdown_exercise_name.grid(row=3, column=1, padx=10, pady=5, sticky="w")
       
        self.lbl_student_user_name=tk.Label(self.display_frame,text='Student User Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_student_user_name.grid(row=4,column=0,sticky = 'W', pady = 20)
        self.dropdown_student_user_name = ttk.Combobox(self.display_frame, values=self.students_list,font=('Arial',20))
        self.dropdown_student_user_name.grid(row=4, column=1, padx=10, pady=5, sticky="w")

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=5,column=0, pady = (20,200))
        self.btn_assign=tk.Button(self.display_frame,text='Assign',font=('Arial',15),bg='cyan3', command=self.assign_quiz_command)
        self.btn_assign.grid(row=5,column=2, pady = (20,200))

    def callback(self,eventObject):
        abc = eventObject.widget.get()
        category= self.dropdown_category.get()
        exercise_list = db.get_exercise_for_category(category,self.student_user_name,self.teacher_id)
        self.dropdown_exercise_name.config(values=exercise_list)

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()
            
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
    
    def assign_quiz_command(self):
        self.cancel_command()
        print("Assign Quiz button ")
        

