import tkinter as tk
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox

class QuizMenu:
    def __init__(self, master,header_frame,display_frame,teacher_id):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        ###########################################################
        self.header_frame=tk.Frame(self.master,background="cyan4")
        self.header_frame.grid(row=0,column=0)        
        add_quiz_header_lbl = tk.Label(self.header_frame, text="Select one of the following Category!", font=('Arial', 24), bg='cyan4', fg='white')
        add_quiz_header_lbl.grid(row=1,column=0,sticky = 'W', pady = 5)
        
        self.display_frame=tk.Frame(self.master,background="cyan4")
        self.display_frame.grid(row=1,column=0)
        text_list=['Sentence Builder','Odd One Out Image Challenge','Category-Based Image Selection Quiz','Alphabet Scramble (Spelling)']
        
        pad_y = 30
        for i in range(0,4):
            self.btn_cat=tk.Button(self.display_frame,text=text_list[i], width=40,bg='cyan3',font=('Arial',15), command=lambda myrow=i: self.btn_actions(myrow))
            if i != 3:
                self.btn_cat.grid(row=i+2,column=3, pady =(0,pad_y))
            else:
                self.btn_cat.grid(row=i+2,column=3, pady =(0,pad_y+100))

        
    def btn_actions(self,row):
        if row==0:
            self.sentence_builder_screen()
        elif row==1:
            self.odd_one_out_image_challenge_screen()
        elif row==2:
            self.category_base_image_selection_quiz()
        else:
            self.alphabet_scramble_screen()
    
    def sentence_builder_screen(self):
        print("This is sentence builder screen!")

    def odd_one_out_image_challenge_screen(self):
        print("This is odd one out screen!")

    def category_base_image_selection_quiz(self):
        print("This is categorybase image screen")

    def alphabet_scramble_screen(self):
        print("This is alphabet scramble screen")


    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()    




