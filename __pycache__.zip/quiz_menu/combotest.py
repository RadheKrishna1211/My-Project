import tkinter as tk
from tkinter import ttk

def update_second_combobox(event):
    selected_value = combobox_var.get()
    if selected_value == "Option 1":
        second_combobox['values'] = ("A", "B", "C")
    elif selected_value == "Option 2":
        second_combobox['values'] = ("X", "Y", "Z")
    else:
        second_combobox['values'] = ()

root = tk.Tk()
root.title("Combobox Example")

# Create and place the first combobox
combobox_var = tk.StringVar(root)
combobox = ttk.Combobox(root, textvariable=combobox_var, values=("Option 1", "Option 2", "Option 3"))
combobox.grid(row=0, column=0)
combobox.bind("<<ComboboxSelected>>", update_second_combobox)

# Create and place the second combobox
second_combobox_var = tk.StringVar(root)
second_combobox = ttk.Combobox(root, textvariable=second_combobox_var)
second_combobox.grid(row=1, column=0)

root.mainloop()
