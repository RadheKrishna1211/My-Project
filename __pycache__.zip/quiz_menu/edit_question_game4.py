import tkinter as tk
import database_code as db
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
from tkinter import PhotoImage
from tkinter import ttk

class EditQuestionsGame4:
    def __init__(self, master,header_frame,display_frame,teacher_id,exercise_id,question_row):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        self.exercise_id = exercise_id
        self.exercise_name= db.get_exercise_name_for_id(self.exercise_id, self.teacher_id)
        self.question_row=question_row
        self.list = db.get_exercise_name_category(self.exercise_name,self.teacher_id)
        print("EDITQGAME4 returned list in edit question game 4", self.list)
        self.category = self.list[0][1]

        questions = db.check_question_game4_exists(exercise_id,teacher_id,question_row[0])
        if questions:
            self.image_objects = ["","","",""]
            print("question row////", self.question_row[0], self.question_row[1])
            self.image_paths = [self.question_row[1],self.question_row[2],self.question_row[3],self.question_row[4]]
            self.answer_options = [1,2,3,4]
        
            for i in range(0,4):
                resized_image = self.resize_image(self.image_paths[i],300,150)
                photo = ImageTk.PhotoImage(resized_image)
                self.image_objects[i] = photo  
            
            print("EDITQGAME4  exercise fetched in editing")
            print(questions)
            lbl_heading_odd_one_out = tk.Label(self.display_frame, text='Odd One Out Exercise', font=('Arial', 20), bg='Cyan4', fg='White')
            lbl_heading_odd_one_out.grid(row=1, column=1, pady=10)

            self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial', 20), bg='Cyan4', fg='White')
            self.lbl_exercise_name.grid(row=2, column=0, pady=10, padx=10)

            self.lbl_exercise_name_display = tk.Label(self.display_frame, text=self.exercise_name, font=('Arial', 20), bg='Cyan4', fg='White')
            self.lbl_exercise_name_display.grid(row=2, column=1, pady=10, padx=10)

            self.btn_open = []
            self.lbl_image = []

            for i in range(4):
                btn_open = tk.Button(self.display_frame, text=f"Open Image {i+1}", font=('Arial', 20),bg='Cyan4',fg='White',command=lambda idx=i: self.open_image(idx))
                btn_open.grid(row=i//2 + 3, column=i%2, padx=20, pady=10)
                self.btn_open.append(btn_open)

                lbl_image = tk.Label(self.display_frame, image=self.image_objects[i],bg='Cyan4')
                lbl_image.grid(row=i//2 + 3, column=i%2 + 2, padx=20, pady=10)
                self.lbl_image.append(lbl_image)

            self.lbl_answer= tk.Label(self.display_frame, text="Answer Option", font=('Arial', 20), bg='Cyan4', fg='White')
            self.lbl_answer.grid(row=6, column=0,pady=5, padx=10)
            
            self.dropdown_answer = ttk.Combobox(self.display_frame, values=self.answer_options,font=('Arial',20))
            self.dropdown_answer.grid(row=6, column=1, padx=10, pady=5, sticky="w")
            qno = int(self.question_row[5]) - 1
            self.dropdown_answer.current(qno)
            self.btn_cancel = tk.Button(self.display_frame, text='Cancel', font=('Arial', 15), bg='cyan3', command=self.cancel_command)
            self.btn_cancel.grid(row=7, column=0, pady=(20,200))

            self.btn_submit = tk.Button(self.display_frame, text='Submit', font=('Arial', 15), bg='cyan3', command=self.update_question_game4_data)
            self.btn_submit.grid(row=7, column=1, pady=(20,200))           
        else:
            messagebox.showerror("Quiz Menu","There was an error in questions Selection!")

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
    

    def update_question_game4_data(self):
        print("EDITQGAME4  update game 4 question ")
        flag =  True
        self.answer_option = self.dropdown_answer.get()
        print("ODDONEOUT Answer option")
        if self.answer_option=="":
            print("inside answer empty")
            flag = False
        for pth in self.image_paths:
            if pth == "":
                print("inside pth empty", pth)
                flag = False
                break
        if flag:
            
            db.update_question_game4(self.exercise_id, self.question_row[0], self.image_paths, int(self.answer_option), self.teacher_id)
            messagebox.showinfo('Quiz Menu','Question Updated Successfully!!')
        else:
            messagebox.showerror('Quiz Menu',"You need to select all the images using the 4 buttons and the answer option!")

        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    
    def open_image(self, index):
        file_path = filedialog.askopenfilename(title=f"Open Image {index} File", filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp *.ico")])
        if file_path:
            resized_image = self.resize_image(file_path,300,150)
            #image = Image.open(file_path)
            photo = ImageTk.PhotoImage(resized_image)
            self.image_objects[index] = photo  
            self.image_paths[index] = file_path  
            self.display_image( photo, index)
            
    def resize_image(self, image_path, width, height):
        # Open the image file
        original_image = Image.open(image_path)

        # Resize the image
        resized_image = original_image.resize((width, height), Image.ANTIALIAS)

        return resized_image
    
    def display_image(self, photo, index):
        self.lbl_image[index].config(image=photo)
