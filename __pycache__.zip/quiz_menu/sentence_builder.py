import tkinter as tk
from tkinter import messagebox
import database_code as db 

class SentenceBuilder:
    def __init__(self, master, header_frame, display_frame,exercise_id,teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.exercise_id = exercise_id
        self.teacher_id=teacher_id

        self.exercise_name = db.get_exercise_name_for_id(self.exercise_id,self.teacher_id)
        print("exercise name for id", self.exercise_name)
        
        self.master = master
        self.master.state('zoomed')
        lbl_heading_sentence_builder = tk.Label(self.header_frame, text='Sentence Builder Exercise ', font=('Arial', 20), bg='Cyan4', fg='White')
        lbl_heading_sentence_builder.grid(row=0, column=3, pady=10)

        self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=1, column=0, pady=10, padx=10)

        self.lbl_exercise_name_display = tk.Label(self.display_frame, text=self.exercise_name, font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name_display.grid(row=1, column=1, pady=10, padx=10)

        self.lbl_enter_sentence = tk.Label(self.display_frame, text='Enter a Sentence 2 to 6 words:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_enter_sentence.grid(row=2, column=0, pady=10, padx=10)
        self.txtbox_enter_sentence=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_enter_sentence.grid(row=2,column=1,sticky = 'W', pady = 20)

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=3,column=0, pady = (20,200))
        self.btn_submit=tk.Button(self.display_frame,text='Submit',font=('Arial',15),bg='cyan3',command=self.submit_command)
        self.btn_submit.grid(row=3,column=1, pady = (20,200))
      
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def submit_command(self):
        self.sentence =self.txtbox_enter_sentence.get()
        count = len(self.sentence.split())
        if count <=1:
            messagebox.showerror('Quiz Menu',"Sentences are too short! enter sentences with 2 to 6 words")
        elif count > 6: 
            messagebox.showerror('Quiz Menu',"Sentences are too long! enter sentences with 2 to 6 words")
        else:
            self.insert_sentence_question(self.exercise_id,self.sentence,self.teacher_id)
            
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def insert_sentence_question(self, exercise_id,sentence,teacher_id):
        question_count = db.get_last_question_number(exercise_id,teacher_id)
        
        print(question_count)
        if question_count[0] == None:
            question_number =  1
        else:
            question_number = question_count[0] + 1

        db.insert_sentence_question(exercise_id, question_number, sentence,teacher_id)
        messagebox.showinfo('Quiz Menu',"Sentence type Question Successfully Created")

    def clear_frame(self,frame):
        for widget in frame.winfo_children():
            widget.destroy()

