import tkinter as tk
from tkinter import font
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import database_code as db
from tkinter import ttk

class OddOneOut:
    def __init__(self, master, header_frame, display_frame, exercise_id, teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.exercise_id = exercise_id
        self.teacher_id = teacher_id

        self.exercise_name = db.get_exercise_name_for_id(self.exercise_id,self.teacher_id)
        print("exercise name for id", self.exercise_name)

        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.master.state('zoomed')
        self.image_objects = ["","","",""]
        self.image_paths = ["","","",""]
        self.answer_option = [1,2,3,4]


        lbl_heading_odd_one_out = tk.Label(self.display_frame, text='Odd One Out Exercise', font=('Arial', 20), bg='Cyan4', fg='White')
        lbl_heading_odd_one_out.grid(row=1, column=1, pady=10)

        self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial', 20), bg='Cyan4', fg='White')
        self.lbl_exercise_name.grid(row=2, column=0, pady=10, padx=10)

        self.lbl_exercise_name_display = tk.Label(self.display_frame, text=self.exercise_name, font=('Arial', 20), bg='Cyan4', fg='White')
        self.lbl_exercise_name_display.grid(row=2, column=1, pady=10, padx=10)

        self.btn_open = []
        self.lbl_image = []

        for i in range(4):
            btn_open = tk.Button(self.display_frame, text=f"Open Image {i+1}", font=('Arial', 20),bg='Cyan4',fg='White',command=lambda idx=i: self.open_image(idx))
            btn_open.grid(row=i//2 + 3, column=i%2, padx=20, pady=10)
            self.btn_open.append(btn_open)

            lbl_image = tk.Label(self.display_frame, bg='Cyan4')
            lbl_image.grid(row=i//2 + 3, column=i%2 + 2, padx=20, pady=10)
            self.lbl_image.append(lbl_image)

        self.lbl_answer= tk.Label(self.display_frame, text="Answer Option", font=('Arial', 20), bg='Cyan4', fg='White')
        self.lbl_answer.grid(row=6, column=0,pady=5, padx=10)
        
        self.dropdown_answer = ttk.Combobox(self.display_frame, values=self.answer_option,font=('Arial',20))
        self.dropdown_answer.grid(row=6, column=1, padx=10, pady=5, sticky="w")

        self.btn_cancel = tk.Button(self.display_frame, text='Cancel', font=('Arial', 15), bg='cyan3', command=self.cancel_command)
        self.btn_cancel.grid(row=7, column=0, pady=(20,200))

        self.btn_submit = tk.Button(self.display_frame, text='Submit', font=('Arial', 15), bg='cyan3', command=self.submit_command)
        self.btn_submit.grid(row=7, column=1, pady=(20,200))

    def open_image(self, index):
        file_path = filedialog.askopenfilename(title=f"Open Image {index} File", filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp *.ico")])
        if file_path:
            resized_image = self.resize_image(file_path,300,150)
            #image = Image.open(file_path)
            photo = ImageTk.PhotoImage(resized_image)
            self.image_objects[index] = photo  
            self.image_paths[index] = file_path  
            self.display_image( photo, index)

    def display_image(self, photo, index):
        self.lbl_image[index].config(image=photo)

    def resize_image(self, image_path, width, height):
        # Open the image file
        original_image = Image.open(image_path)

        # Resize the image
        resized_image = original_image.resize((width, height), Image.ANTIALIAS)

        return resized_image
    

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def submit_command(self):
        print("ODDONEOUT inside submit")
        #print("Selected image paths:", self.image_paths)
        print("latest image paths....",self.image_paths[0])
        #print("latest image paths....",self.image_paths[1])
        #print("latest image paths....",self.image_paths[2])
        #print("latest image paths....",self.image_paths[3])
        print("ODDONEOUT inside submit line 91")
        flag =  True
        self.answer_option = self.dropdown_answer.get()
        print("ODDONEOUT Answer option")
        if self.answer_option=="":
            print("inside answer empty")
            flag = False
        for pth in self.image_paths:
            if pth == "":
                print("inside pth empty", pth)
                flag = False
                break
        if flag:
            self.insert_odd_one_out_question(self.exercise_id,self.image_paths,int(self.answer_option),self.teacher_id)
        else:
            messagebox.showerror('Quiz Menu',"You need to select all the images using the 4 buttons and the answer option!")

        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def insert_odd_one_out_question(self, exercise_id, image_paths,answer,teacher_id):
        print("ODDONEOUT Insert question insert",exercise_id)
        question_count = db.get_last_question_number(exercise_id,teacher_id)
        print(question_count)
        if question_count[0] == None:
            question_number =  1
        else:
            question_number = question_count[0] + 1
        print("latest image paths....",image_paths[0])
        print("latest image paths....",image_paths[1])
        print("latest image paths....",image_paths[2])
        print("latest image paths....",image_paths[3])

        db.insert_odd_one_out_question(exercise_id, question_number,image_paths,answer,teacher_id)
        messagebox.showinfo('Quiz Menu',"Odd One Out Image Challenge Question Successfully Created")

    def clear_frame(self, frame):
        for widget in frame.winfo_children():
            widget.destroy()
