import tkinter as tk
import database_code as db
from tkinter import messagebox
import quiz_menu.edit_exercise as eq

class EditDeleteExercise:
    def __init__(self, master,header_frame, display_frame, teacher_id):
        self.teacher_id = teacher_id
        self.master = master
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.checkbox_vars_edit_delete_list = []
        print("inside editdelete exercise")
        
        self.exercises=db.edit_delete_exercise(self.teacher_id)
        
        if len(self.exercises)!=0:
            self.lbl_header=tk.Label(self.header_frame,text='Edit / Delete Exercise Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 1)
            self.create_table()
        else:
            messagebox.showerror('Quiz Menu','You havent added any exercise, please add exercise!')
    
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def create_table(self):        
        column_headers = ["Exercise Name", "Category", "Exercise Description","Edit/Delete"]
        for col, header in enumerate(column_headers):
            label = tk.Label(self.display_frame, text=header, borderwidth=1, font=('Arial',20),bg='Cyan4',fg='White')
            label.grid(row=0, column=col,sticky = 'W', pady = 2)
        
        for row, data_row in enumerate(self.exercises, start=1):
            print("in enumerating rows.....................")
            print("printing row number")
            print(row)
            for col, cell_value in enumerate(data_row):
                label = tk.Label(self.display_frame, text=cell_value, borderwidth=1, font=('Arial',20),bg='Cyan4',fg='White')
                label.grid(row=row, column=col,sticky = 'W', pady = 2)
            checkbox_var = tk.BooleanVar(value=False)
            checkbox = tk.Checkbutton(self.display_frame, variable=checkbox_var,command=lambda myrow=row: self.clear_other_checkboxes(myrow, self.checkbox_vars_edit_delete_list))
            checkbox.grid(row=row, column=3) 
            self.checkbox_vars_edit_delete_list.append(checkbox_var)              

        self.btn_edit=tk.Button(self.display_frame,text='Edit',bg='cyan3',font=('Arial',15), command=self.edit_exercise_screen)
        self.btn_edit.grid(row=len(self.exercises)+1,column=1, pady = (10,10))
        self.btn_delete=tk.Button(self.display_frame,text='Delete',bg='cyan3',font=('Arial',15), command=self.delete_exercise_screen)
        self.btn_delete.grid(row=len(self.exercises)+1,column=2, pady = (10,10))    
        
    def edit_exercise_screen(self):
        print("edit exercise")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for deleting")
        else:
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
            eq.EditExercise(self.master,self.header_frame,self.display_frame,self.teacher_id,self.exercises[row_selected][0])

    def delete_exercise_screen(self):
        print("inside delete exercise screen function")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for deleting")
        else:
            print(self.exercises[row_selected])
            print(self.exercises[row_selected][0])
            self.exercise_id = db.get_exercise_id(self.exercises[row_selected][0],self.teacher_id)
            print("exercise id to be deleted", self.exercise_id)
            db.delete_exercise(self.exercise_id,self.teacher_id)
            messagebox.showinfo('Quiz Menu','You have successfully deleted the exercise!')
            self.clear_frame(self.display_frame)
            self.clear_frame(self.header_frame)

    def clear_other_checkboxes(self,row, checkbox_list):
        for i, checkbox in enumerate(checkbox_list):
            if i+1 != row:
                checkbox.set(False)
    