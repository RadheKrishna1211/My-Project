import tkinter as tk
from tkinter import font
from tkinter import ttk
import database_code as db
from tkinter import messagebox

class EditExercise:
    def __init__(self, master,header_frame,display_frame,teacher_id,exercise_name):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        
        self.exercise_name = exercise_name
        self.categories = ["Sentence Builder", "Alphabet Scramble","Objective Type","Odd One Out Image"]
        exercise = db.check_exercise_exists(exercise_name,teacher_id)
        print("exercise fetched in editing",exercise_name)
        print(exercise)
        if exercise:
            print("inside edit exercise")
            self.lbl_header=tk.Label(self.header_frame,text='Edit exercise Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=1,sticky = 'W', pady = 20)

            self.lbl_exercise_name=tk.Label(self.display_frame,text='Exercise Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name.grid(row=1,column=0,sticky = 'W', pady = 20)
            self.lbl_exercise_name_display=tk.Label(self.display_frame,text=exercise_name,font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_name_display.grid(row=1,column=1,sticky = 'W', pady = 20)
            
            self.lbl_category=tk.Label(self.display_frame,text='Category :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_category.grid(row=2,column=0,sticky = 'W', pady = 20)
            self.dropdown_category = ttk.Combobox(self.display_frame, values=self.categories,font=('Arial',20))
            self.dropdown_category.grid(row=2, column=1, padx=10, pady=5, sticky="w")
            #(0,exercise[0][2])
            index=0
            
            for element in self.categories:
                if element == exercise[0][2]:
                    break
                index=index+1
            print("index", index)
            self.dropdown_category.current(index) 

            self.lbl_exercise_description=tk.Label(self.display_frame,text='Exercise Description :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_exercise_description.grid(row=3,column=0,sticky = 'W', pady = 20)
            
            self.txtbox_exercise_description=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_exercise_description.grid(row=3,column=1,sticky = 'W', pady = 20)
            self.txtbox_exercise_description.insert(0,exercise[0][3])
           
            self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
            self.btn_cancel.grid(row=4,column=0, pady = (20,200))
            self.btn_submit=tk.Button(self.display_frame,text='Submit',bg='cyan3',font=('Arial',15), command=self.update_exercise_data)
            self.btn_submit.grid(row=4,column=1, pady = (20,200))
        else:
            messagebox.showerror("Quiz Menu","There was an error in Exercise Selection!")

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def update_exercise_data(self):
        print("inside edit ex update exercise data...")
        self.category=self.dropdown_category.get()
        self.exercise_description = self.txtbox_exercise_description.get()
        self.exercise_id = db.get_exercise_id(self.exercise_name, self.teacher_id)
        print("inside edit ex update exercise data... ex id", self.exercise_id)
        if self.category=='' or self.exercise_description=='' :
            messagebox.showerror('Quiz Menu','Blanks are not allowed')
        else:
            print("inside edit ex update exercise data... else", self.exercise_id,self.category,self.exercise_description)
            self.update_exercise(self.exercise_id,self.category,self.exercise_description)
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
           
    def update_exercise(self, exercise_id,category,exercise_description):
        print("inside edit ex update exercise...",exercise_id,category,exercise_description)
        db.update_exercise(exercise_id,category,exercise_description,self.teacher_id)
        messagebox.showinfo('Quiz Menu','exercise Updated Successfully!!')

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
