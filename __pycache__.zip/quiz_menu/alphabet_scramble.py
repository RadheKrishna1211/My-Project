import tkinter as tk
from tkinter import messagebox
import database_code as db
 
class AlphabetScramble:
    def __init__(self, master, header_frame, display_frame,exercise_id,teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.exercise_id=exercise_id
        self.teacher_id=teacher_id
        self.master = master
        self.exercise_name = db.get_exercise_name_for_id(self.exercise_id,self.teacher_id)
        print("exercise name for id", self.exercise_name)

        self.master.state('zoomed')
        lbl_heading_alphabet_scramble = tk.Label(self.header_frame, text='Alphabet Scramble Exercise ', font=('Arial', 20), bg='Cyan4', fg='White')
        lbl_heading_alphabet_scramble.grid(row=0, column=5, pady=10)
        
        self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=1, column=0, pady=10, padx=10)
        self.lbl_exercise_name_display = tk.Label(self.display_frame, text=self.exercise_name, font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name_display.grid(row=1, column=1, pady=10, padx=10)

        self.lbl_enter_word = tk.Label(self.display_frame, text='Enter a Word 2 to 6 letters:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_enter_word.grid(row=2, column=0, pady=10, padx=10)
        self.txtbox_enter_word=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_enter_word.grid(row=2,column=1,sticky = 'W', pady = 20)

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=3,column=1, pady = (20,200))
        self.btn_submit=tk.Button(self.display_frame,text='Submit',font=('Arial',15),bg='cyan3',command=self.submit_command)
        self.btn_submit.grid(row=3,column=2, pady = (20,200))
      
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def submit_command(self):

        self.word =self.txtbox_enter_word.get()
        print(self.word)
        count = len(self.word.split(' '))
        print(count)
        if count > 1:
            messagebox.showinfo('Quiz Menu', "Word should only be 1")
        elif self.word =="": 
            messagebox.showinfo('Quiz Menu',"The word cannot textbox cannot be empty")
        elif len(self.word)>6 or len(self.word)==1: 
            messagebox.showinfo('Quiz Menu',"The word cannot have more than 6 letters or should not be one letter")
        else:
            self.category="Alphabet Scramble"
            self.insert_alphabet_question(self.exercise_id,self.word,self.teacher_id)
            
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def insert_alphabet_question(self, exercise_id,word,teacher_id):
        question_count = db.get_last_question_number(exercise_id,teacher_id)
        print(question_count)
        if question_count[0] == None:
            question_number =  1
        else:
            question_number = question_count[0] + 1
        db.insert_word_question(exercise_id, question_number, word,teacher_id)
        messagebox.showinfo('Quiz Menu',"Alphabet Scramble Question Successfully Created")


    def clear_frame(self,frame):
        for widget in frame.winfo_children():
            widget.destroy()
