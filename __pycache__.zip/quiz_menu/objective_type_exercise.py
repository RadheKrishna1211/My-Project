import tkinter as tk
from tkinter import font
from tkinter import messagebox
import database_code as db
from tkinter import ttk

class ObjectiveQuestion:
    def __init__(self, master, header_frame, display_frame,exercise_id,teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.exercise_id=exercise_id
        self.teacher_id=teacher_id

        self.exercise_name = db.get_exercise_name_for_id(self.exercise_id,self.teacher_id)
        print("exercise name for id", self.exercise_name)

        self.master = master
        bigfont = font.Font(family="Arial",size=20)
        self.master.option_add("*TCombobox*Listbox*Font", bigfont) 
        self.master.state('zoomed')
        self.answer_option = [1,2,3,4]

        self.lbl_heading_objective_type_exercise = tk.Label(self.header_frame, text='Objective Type Exercise ', font=('Arial', 20), bg='Cyan4', fg='White')
        self.lbl_heading_objective_type_exercise.grid(row=0, column=1, pady=10,padx=10)

        self.lbl_exercise_name = tk.Label(self.display_frame, text='Exercise Name:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name.grid(row=1, column=0, pady=10, padx=10)
        self.lbl_exercise_name_display = tk.Label(self.display_frame, text=self.exercise_name, font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_exercise_name_display.grid(row=1, column=1, pady=10, padx=10)

        self.lbl_question = tk.Label(self.display_frame, text='Question:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_question.grid(row=2, column=0, pady=10, padx=10)
        self.txtbox_question=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_question.grid(row=2,column=1,sticky = 'W', pady = 20)

        self.lbl_option1 = tk.Label(self.display_frame, text='Option 1', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_option1.grid(row=3, column=0, pady=10, padx=10)
        self.txtbox_option1=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_option1.grid(row=3,column=1,sticky = 'W', pady = 20)

        self.lbl_option2 = tk.Label(self.display_frame, text='Option 2', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_option2.grid(row=3, column=2, pady=10, padx=10)
        self.txtbox_option2=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_option2.grid(row=3,column=3,sticky = 'W', pady = 20)

        self.lbl_option3 = tk.Label(self.display_frame, text='Option 3', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_option3.grid(row=4, column=0, pady=10, padx=10)
        self.txtbox_option3=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_option3.grid(row=4,column=1,sticky = 'W', pady = 20)

        self.lbl_option4 = tk.Label(self.display_frame, text='Option 4', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_option4.grid(row=4, column=2, pady=10, padx=10)
        self.txtbox_option4=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_option4.grid(row=4,column=3,sticky = 'W', pady = 20)

        self.lbl_answer = tk.Label(self.display_frame, text='Answer Option:', font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_answer.grid(row=5, column=0, pady=10, padx=10)
        self.dropdown_answer = ttk.Combobox(self.display_frame, values=self.answer_option,font=('Arial',20))
        self.dropdown_answer.grid(row=5, column=1, padx=10, pady=5, sticky="w")

        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='Cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=6,column=0, pady = (20,100))
        self.btn_submit=tk.Button(self.display_frame,text='Submit',font=('Arial',15),bg='Cyan3',command=self.submit_command)
        self.btn_submit.grid(row=6,column=1, pady = (20,100))
    
    def clear_frame(self,frame):
        for widget in frame.winfo_children():
            widget.destroy()

    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

    def submit_command(self):
        self.obj_question =self.txtbox_question.get()
        self.option1=self.txtbox_option1.get()
        self.option2=self.txtbox_option2.get()
        self.option3=self.txtbox_option3.get()
        self.option4=self.txtbox_option4.get()
        self.answer=self.dropdown_answer.get()

        if self.obj_question=="" and self.option1=="" and self.option2=="" and self.option3=="" and self.option4=="" and self.answer=="":
            messagebox.showinfo('Quiz Menu',"Question,options and Answer cannot  be empty")
        else:
            self.insert_objective_type_question(self.exercise_id,self.obj_question,self.option1,self.option2,self.option3,self.option4,self.answer, self.teacher_id)
            print("inside submit of obj type question")
 
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
    
    def insert_objective_type_question(self, exercise_id,obj_question,option1,option2,option3,option4,answer,teacher_id):
        question_count = db.get_last_question_number(exercise_id,teacher_id)
        print(question_count)
        if question_count[0] == None:
            question_number =  1
        else:
            question_number = question_count[0] + 1

        db.insert_objective_type_question(exercise_id, question_number,obj_question,option1,option2,option3,option4,answer,teacher_id)
        messagebox.showinfo('Quiz Menu',"Objective Type Question Successfully Created")

    
    
