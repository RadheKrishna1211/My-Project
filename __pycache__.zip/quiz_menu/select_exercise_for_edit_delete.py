import tkinter as tk
from tkinter import ttk
import database_code as db
import quiz_menu.sentence_builder as sb
import quiz_menu.alphabet_scramble as ab
import quiz_menu.objective_type_exercise as oq
from tkinter import messagebox
import quiz_menu.edit_delete_game2 as edg2
import quiz_menu.edit_delete_game1 as edg1
import quiz_menu.edit_delete_game3 as edg3
import quiz_menu.edit_delete_game4 as edg4


class SelectExerciseEditDelete:
    def __init__(self, master, header_frame, display_frame, teacher_id):
        self.header_frame = header_frame
        self.display_frame = display_frame
        self.master = master
        self.master.state('zoomed')
        self.teacher_id= teacher_id
        self.no_of_words = [1,2,3,4,5,6]
        self.exercise_names=db.get_exercise_names(teacher_id)
        if len(self.exercise_names)==0:
            messagebox.showerror('Quiz Menu','There are no Exercises to edit delete Quizzes to. Please create Exercises!')
        else:
            self.lbl_heading_quiz_question = tk.Label(self.header_frame, text='Select Exercise to edit / delete Questions:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_heading_quiz_question.grid(row=0, column=0, pady=10)
            
            self.lbl_select_exercise = tk.Label(self.display_frame, text='Select Exercise:', font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_select_exercise.grid(row=2, column=0, pady=10, padx=10)
            self.dropdown_select_exercise = ttk.Combobox(self.display_frame, values=self.exercise_names)
            self.dropdown_select_exercise.grid(row=2, column=1, padx=10, pady=5, sticky="w")

            self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',20),bg='cyan3',command=self.cancel_command)
            self.btn_cancel.grid(row=4,column=0, pady = (20,200))
            self.btn_select=tk.Button(self.display_frame,text='Select',font=('Arial',20),bg='cyan3',command=self.select_command)
            self.btn_select.grid(row=4,column=1, pady = (20,200))
        
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()
      
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)
        
    def select_command(self):
        self.exercise_name=self.dropdown_select_exercise.get()
        self.exercise_id = db.get_exercise_id(self.exercise_name,self.teacher_id)
        self.exercise_name_category=db.get_exercise_name_category(self.exercise_name,self.teacher_id)
        print(self.exercise_name_category[0][1])
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)

        if self.exercise_name_category[0][1]=="Alphabet Scramble":
            print("Select exercise for edit delete questions : Alphabet Scramble ")
            #ab.AlphabetScramble(self.master, self.header_frame, self.display_frame,self.exercise_name,self.teacher_id)
            edg1.EditDeleteGame1(self.master, self.header_frame, self.display_frame,self.exercise_name,"Alphabet Scramble",self.teacher_id)

        elif self.exercise_name_category[0][1]=="Sentence Builder":
            print("Select exercise for edit delete questions : Sentence Builder")
            edg2.EditDeleteGame2(self.master, self.header_frame, self.display_frame,self.exercise_name,"Sentence Builder",self.teacher_id)
       
        elif self.exercise_name_category[0][1]=="Objective Type":
            print("Select exercise for edit delete questions : Objective Type")
            #oq.ObjectiveQuestion(self.master, self.header_frame, self.display_frame,self.exercise_name,self.teacher_id)
            edg3.EditDeleteGame3(self.master, self.header_frame, self.display_frame,self.exercise_name,"Objective Type Questions",self.teacher_id)

        else:
            print("Select exercise for edit delete questions : Odd One Out Image")
            edg4.EditDeleteGame4(self.master, self.header_frame, self.display_frame,self.exercise_name,"Odd one out",self.teacher_id)

    

        
        

        


