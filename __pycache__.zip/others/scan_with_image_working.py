import tkinter as tk
import pyttsx3
import sounddevice as sd
import soundfile as sf
import time
from PIL import Image, ImageTk
HCOLOR = "yellow"
BCOLOR = "cyan4"

class ScanTest:
    def __init__(self, master,header_frame,display_frame):
        
        #self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master

        self.master.title("Inclusive Scan and Play Software")
        self.master.state('zoomed')#automatically expands window to full size
        
        self.master.configure(bg='cyan4')
        self.master.rowconfigure(0, weight=1)
        self.master.columnconfigure(0, weight=1)

        self.first_screen_initializations()

        main_screen_header_label = tk.Label(self.header_frame, text="Select the Category!", font=("Arial",30,"bold"),background='#ffffcc',fg='#2D1BA6')
        main_screen_header_label.grid(row=0, column = 1)
       
        self.voice_initializations()

        self.create_first_screen_buttons()
        self.highlight_first_screen_buttons()

        self.master.bind('<Button-1>', self.on_first_screen_mouse_click)

    def first_screen_initializations(self):
        self.first_screen_highlight_flag = 1
        self.first_screen_flag = 0
        self.first_screen_button_widgets = []
        self.first_screen_label_widgets = []
        self.first_screen_counter = 0
        self.first_screen_highlight_index = 0
        self.first_screen_text = ['OPTION 1', 'OPTION 2', 'OPTION 3','OPTION 4']
        self.first_screen_images=["opt1.jpg","opt2.jpg","opt3.jpg","opt4.jpg"]

    def voice_initializations(self):
        self.engine = pyttsx3.init()
        self.engine. setProperty("rate",150)
        voices = self.engine.getProperty('voices')
        self.engine.setProperty('voice', voices[0].id)#female voice
 

    def create_first_screen_buttons(self):
        self.first_screen_button_widgets = []
        self.first_screen_label_widgets = []

        self.image_object_list=[]

        self.first_screen_images = ['opt1.png','opt2.png','opt3.png','opt4.png']
        for i in range(0,len(self.first_screen_text)):
            self.image1 = Image.open(self.first_screen_images[i])
            self.image_object_list.append(ImageTk.PhotoImage(self.image1))

        for i in range(0,len(self.first_screen_text)): 
            
            self.image_label = tk.Label(self.display_frame, height=300,width=300, background=BCOLOR)
            rowval = i//2
            colval = i%2
            self.image_label.grid(row=rowval,column=colval)     
            button = tk.Button(self.image_label,height=150, font=("Arial",20,"bold"),width=300,background=BCOLOR,fg='#2D1BA6')
            button.grid(row=rowval, column=colval, pady=10,padx=20)

            button.configure(image=self.image_object_list[i])
            self.first_screen_button_widgets.append(button)
            self.first_screen_label_widgets.append(self.image_label)

    def highlight_first_screen_buttons(self):
        #since this function is scheduled and called, we are checking a flag whether highlight is required or not
        if self.first_screen_highlight_flag == 1:
            self.first_screen_counter = self.first_screen_counter + 1
            print("in highlight, first screen counter incremented", self.first_screen_counter)
            print(self.first_screen_counter)
            if self.first_screen_counter>=len(self.first_screen_text):
                self.first_screen_counter = 0
                print("in highlight, first screen counter reset", self.first_screen_counter)
            #print(self.first_screen_highlight_index)
            for button in self.first_screen_label_widgets:
                button.config(bg=BCOLOR)  # Reset the background color of all buttons
            
            button_to_highlight = self.first_screen_label_widgets[self.first_screen_highlight_index]
            button_to_highlight.config(bg="yellow")  # Highlight the current button

            if self.first_screen_flag == 0:
                self.first_screen_flag = 1
            else:
                speak_text = self.first_screen_text[self.first_screen_highlight_index-1]
                self.engine.say(speak_text)
                self.engine.runAndWait()
            self.first_screen_highlight_index = (self.first_screen_highlight_index + 1) % len(self.first_screen_label_widgets)  # Move to the next button
            self.master.after(1000, self.highlight_first_screen_buttons)  # Schedule the next highlight

    def on_first_screen_mouse_click(self,event):
        print("hello...................................................")
        print(self.first_screen_highlight_index)
        self.actual_index = -1
        if self.first_screen_highlight_index == 0:
            self.actual_index =  3
        elif self.first_screen_highlight_index == 1:
            self.actual_index =  4
        else:
            self.actual_index = self.first_screen_highlight_index - 1
        print(self.actual_index)
       
        
        self.master.destroy()

def main():
    root = tk.Tk()
    header_frame=tk.Frame(root,background="cyan4")
    header_frame.grid()
    display_frame=tk.Frame(root,background="cyan4")
    display_frame.grid()
    ScanTest(root,header_frame,display_frame)
    root.mainloop()

if __name__ == "__main__":
    main()
        