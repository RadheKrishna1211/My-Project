import sqlite3
from class_representations.teacher import Teacher
DBNAME = 'inclusive_play_database.db'

# Function to create the  tables if it doesn't exist
def create_tables():
    connection = sqlite3.connect(DBNAME)
    #################### TEACHER TABLE ########################################

    cursor = connection.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS teachers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    first_name TEXT NOT NULL,
                    last_name TEXT NOT NULL,
                    user_name TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL)''')
    connection.commit()

    #################### STUDENT TABLE ########################################
    cursor.execute('''CREATE TABLE IF NOT EXISTS students
                            (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             first_name TEXT NOT NULL,
                             last_name TEXT NOT NULL,
                             user_name TEXT UNIQUE NOT NULL,
                             password TEXT NOT NULL,
                             teacher_id TEXT,
                             FOREIGN KEY(teacher_id) REFERENCES teacher(user_name))''')
    connection.commit()

    #################### EXERCISE MASTER TABLE ###############################
    #cursor.execute('''DROP TABLE tbl_exercise_master''')
    #connection.commit()

    cursor.execute('''CREATE TABLE IF NOT EXISTS tbl_exercise_master(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   exercise_name TEXT UNIQUE NOT NULL,
                   category TEXT NOT NULL,
                   exercise_description TEXT,
                   teacher_id Text NOT NULL,
                   FOREIGN KEY(teacher_id) REFERENCES teacher(user_name))''')
    connection.commit()

    #################### EXERCISE DETAILS TABLE ###############################
    #cursor.execute('''DROP TABLE tbl_exercise_details''')
    #connection.commit()
    cursor.execute('''CREATE TABLE IF NOT EXISTS tbl_exercise_details(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   exercise_name TEXT NOT NULL,
                   category TEXT NOT NULL,
                   question_number INTEGER NOT NULL,
                   game1_word TEXT NULL,
                   game2_sentence TEXT NULL,
                   game3_question TEXT NULL,
                   game3_option1 TEXT NULL,
                   game3_option2 TEXT NULL,
                   game3_option3 TEXT NULL,
                   game3_option4 TEXT NULL,
                   game3_answer_option TEXT NULL,
                   game4_option1_image_path STRING NULL,
                   game4_option2_image_path STRING NULL,
                   game4_option3_image_path STRING NULL,
                   game4_option4_image_path STRING NULL,
                   game4_answer_option_path STRING NULL,
                   teacher_id Text NOT NULL,
                   FOREIGN KEY(exercise_name) REFERENCES tbl_exercise_master(id),
                   FOREIGN KEY(category) REFERENCES tbl_exercise_master(id),
                   FOREIGN KEY(teacher_id) REFERENCES teacher(user_name))''')
    connection.commit()

#assign execrcise 
    cursor.execute('''CREATE TABLE IF NOT EXISTS tbl_assign_exercise(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   exercise_name TEXT NOT NULL,
                   category TEXT NOT NULL,
                   student_user_name TEXT NOT NULL,
                   teacher_id Text NOT NULL,
                   FOREIGN KEY(teacher_id) REFERENCES teacher(user_name))''')
    connection.commit()
    connection.close()


    
def insert_teacher(teacher):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("INSERT INTO teachers(first_name, last_name, user_name, password) VALUES (?,?,?,?)",
                             (teacher.first_name,teacher.last_name, teacher.user_name, teacher.password))
    connection.commit()
    connection.close()

def insert_student(student):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("INSERT INTO students(first_name, last_name, user_name, password,teacher_id)  VALUES (?,?,?,?,?)",
                             (student.first_name,student.last_name, student.user_name, student.password,student.teacher_id))
    connection.commit()
    connection.close()

def insert_exercise(exercise):
    print("insert exercise",exercise.exercise_name,exercise.category)
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("INSERT INTO tbl_exercise_master(exercise_name, category, exercise_description,teacher_id)  VALUES (?,?,?,?)",
                             (exercise.exercise_name,exercise.category, exercise.exercise_name,exercise.teacher_id))
    connection.commit()
    connection.close()

def edit_delete_student(user_name):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT first_name,last_name,user_name FROM students WHERE teacher_id=?",(user_name,))
    students = cursor.fetchall()
    connection.close()
    return students

def check_user_exists(user_name):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM teachers WHERE user_name=?",(user_name,))
   
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def check_student_exists(user_name, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM students WHERE user_name=? and teacher_id=?",(user_name,teacher_id))
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def check_exercise_exists(exercise_name, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM tbl_exercise_master WHERE exercise_name=? and teacher_id=?",(exercise_name,teacher_id))
   
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result
   
def check_user_password_match(user_name, password):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM teachers WHERE user_name=? and password=?",(user_name, password ))
        result = cursor.fetchall()
        if not result:
            result = False
    connection.close()
    return result

def delete_student(user_name, teacher_id):
    print("inside delete student in db")
    print(user_name)
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM students WHERE user_name=? and teacher_id=?",(user_name,teacher_id))
    connection.commit()
    connection.close()

def update_student(student_object):
    print("inside update student in db")
    print(student_object.first_name,student_object.last_name,student_object.user_name,student_object.password)
  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update students set first_name =?, last_name =?,  password =? where user_name =? and teacher_id=?"""
    input_data = (student_object.first_name, student_object.last_name, student_object.password, student_object.user_name, student_object.teacher_id)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()

def get_teacher_ids():
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT user_name FROM teachers")
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def check_student_password_match(user_name, password, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM students WHERE user_name=? and password=? and teacher_id=?",(user_name, password, teacher_id))
        result = cursor.fetchall()
        if not result:
            result = False
    connection.close()
    return result

def get_exercise_name(teacher_id):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT exercise_name FROM tbl_exercise_master WHERE teacher_id=?",(teacher_id,))
    exercise_names = cursor.fetchall()
    print(" inside get exercise name",exercise_names)
    ex_list=[]
    for i in exercise_names:
        ex_list.append("".join(i))
    print("ex_list",ex_list)
    connection.close()
    return ex_list

def get_exercise_name_category(exercise_name,teacher_id):
    print("inside db",exercise_name,teacher_id)
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT exercise_name ,category FROM tbl_exercise_master WHERE exercise_name=? and teacher_id=?",(exercise_name,teacher_id))
    exercise_names = cursor.fetchall()
    connection.close()
    print("inside db",exercise_names)
    return exercise_names

def insert_sentence_exercise(exercise_name,category,sentence, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    
    with connection:
        cursor.execute("INSERT INTO tbl_exercise_details(exercise_name, category, question_number, game2_sentence, teacher_id) VALUES (?,?,?,?,?)",
                             (exercise_name,category,1,sentence, teacher_id))
    
    connection.commit()
    connection.close()

def insert_word_exercise(exercise_name,category,word, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    
    with connection:
        cursor.execute("INSERT INTO tbl_exercise_details(exercise_name, category, question_number, game1_word, teacher_id) VALUES (?,?,?,?,?)",
                             (exercise_name,category,1,word, teacher_id))
    
    connection.commit()
    connection.close()

def insert_objective_exercise(exercise_name,category,obj_question ,option1,option2,option3,option4, teacher_id):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    
    with connection:
        cursor.execute("INSERT INTO tbl_exercise_details(exercise_name, category, question_number, game3_question,game3_option1,game3_option2,game3_option3,game3_option4, teacher_id) VALUES (?,?,?,?,?,?,?,?,?)",
                             (exercise_name,category,1,obj_question,option1,option2,option3,option4, teacher_id))
    
    connection.commit()
    connection.close()

def edit_delete_exercise(user_name):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT exercise_name,category,exercise_description FROM tbl_exercise_master WHERE teacher_id=?",(user_name,))
    exercises = cursor.fetchall()
    connection.close()
    return exercises

def update_exercise(exercise_name,category,exercise_description,teacher_id):
    print("inside update exercise in db")  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update tbl_exercise_master set category=?,  exercise_description =? where exercise_name =? and teacher_id=?"""
    input_data = (category, exercise_description,exercise_name, teacher_id)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()

def delete_exercise(exercise_name, teacher_id):
    print("inside delete exercise in db")
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM tbl_exercise_master WHERE exercise_name=? and teacher_id=?",(exercise_name,teacher_id))
    connection.commit()
    connection.close()

def edit_delete_question_game2(exercise_name,teacher_id):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT question_number,game2_sentence FROM tbl_exercise_details WHERE teacher_id=? and exercise_name=?",(teacher_id,exercise_name))
    questions = cursor.fetchall()
    connection.close()
    return questions

def update_question_game2(exercise_name,category,question_number,sentence,teacher_id):
    print("inside update game2 questions in db")  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update tbl_exercise_details set game2_sentence=? where exercise_name =? and teacher_id=? and question_number=?"""
    input_data = (sentence,exercise_name, teacher_id,question_number)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()

def check_question_game2_exists(exercise_name, teacher_id,category,question_number):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM tbl_exercise_details WHERE exercise_name=? and teacher_id=? and question_number=?",(exercise_name,teacher_id,question_number))  
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def delete_question_game2(question_number ,exercise_name,teacher_id):
    print("inside delete questions in db")
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM tbl_exercise_details WHERE question_number=?,exercise_name=? and teacher_id=?",(question_number,exercise_name,teacher_id))
    connection.commit()
    connection.close()

#for game1 i.e Alphabet scramble

def edit_delete_question_game1(exercise_name,teacher_id):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT question_number,game1_word FROM tbl_exercise_details WHERE teacher_id=? and exercise_name=?",(teacher_id,exercise_name))
    questions = cursor.fetchall()
    connection.close()
    return questions

def update_question_game1(exercise_name,category,question_number,word,teacher_id):
    print("inside update game1 questions in db")  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update tbl_exercise_details set game1_word=? where exercise_name =? and teacher_id=? and question_number=?"""
    input_data = (word,exercise_name, teacher_id,question_number)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()

def check_question_game1_exists(exercise_name, teacher_id,category,question_number):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM tbl_exercise_details WHERE exercise_name=? and teacher_id=? and question_number=?",(exercise_name,teacher_id,question_number))  
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def delete_question_game1(question_number ,exercise_name,teacher_id):
    print("inside delete word in db")
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM tbl_exercise_details WHERE question_number=?,exercise_name=? and teacher_id=?",(question_number,exercise_name,teacher_id))
    connection.commit()
    connection.close()



#for game3 i.e objective type

def edit_delete_question_game3(exercise_name,teacher_id):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT question_number,game3_question,game3_option1,game3_option2,game3_option3,game3_option4,game3_answer_option FROM tbl_exercise_details WHERE teacher_id=? and exercise_name=?",(teacher_id,exercise_name))
    questions = cursor.fetchall()
    connection.close()
    return questions
                  

def update_question_game3(exercise_name, category, question_number, answer_option, teacher_id):
    print("inside update game1 questions in db")  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update tbl_exercise_details set game3_answer_option=? where exercise_name =? and teacher_id=? and question_number=?"""
    input_data = (answer_option, exercise_name, teacher_id, question_number)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()


def check_question_game3_exists(exercise_name, teacher_id,category,question_number):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM tbl_exercise_details WHERE exercise_name=? and teacher_id=? and question_number=?",(exercise_name,teacher_id,question_number))  
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def delete_question_game3(question_number ,exercise_name,teacher_id):
    print("inside delete word in db")
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM tbl_exercise_details WHERE question_number=? and exercise_name=? and teacher_id=?",(question_number,exercise_name,teacher_id))
    connection.commit()
    connection.close()


#for game4 i.e objective type

def edit_delete_question_game4(exercise_name,teacher_id):
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT question_number,game4_option1_image_path,game4_option2_image_path,game4_option3_image_path,game4_option4_image_path,game4_answer_option_path FROM tbl_exercise_details WHERE teacher_id=? and exercise_name=?",(teacher_id,exercise_name))
    questions = cursor.fetchall()
    connection.close()
    return questions
                  

def update_question_game4(exercise_name, category, question_number, answer_option, teacher_id):
    print("inside update game4 questions in db")  
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()  
    sql_update_query = """Update tbl_exercise_details set game4_answer_option_path=? where exercise_name =? and teacher_id=? and question_number=?"""
    input_data = (answer_option, exercise_name, teacher_id, question_number)
    cursor.execute(sql_update_query, input_data)
    connection.commit()
    connection.close()


def check_question_game4_exists(exercise_name, teacher_id,category,question_number):
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("SELECT * FROM tbl_exercise_details WHERE exercise_name=? and teacher_id=? and question_number=?",(exercise_name,teacher_id,question_number))  
        result = cursor.fetchall()
        if not result:
            result=False
    connection.close()
    return result

def delete_question_game4(question_number ,exercise_name,teacher_id):
    print("inside delete word in db")
    connection = sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    with connection:
        cursor.execute("DELETE FROM tbl_exercise_details WHERE question_number=? and exercise_name=? and teacher_id=?",(question_number,exercise_name,teacher_id))
    connection.commit()
    connection.close()


def get_exercise_for_category(category,student_user_name,teacher_id):
    print("")
    connection= sqlite3.connect(DBNAME)
    cursor = connection.cursor()
    cursor.execute("SELECT exercise_name ,category FROM tbl_assign_exercise WHERE student_user_name=? and teacher_id=?",(student_use_name,teacher_id))
    exercise_names = cursor.fetchall()
    connection.close()
    print("inside db",exercise_names)
    return exercise_names


