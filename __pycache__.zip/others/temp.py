import tkinter as tk
from PIL import Image, ImageTk

def resize_image(image_path, width, height):
    # Open the image file
    original_image = Image.open(image_path)

    # Resize the image
    resized_image = original_image.resize((width, height), Image.ANTIALIAS)

    return resized_image

def show_resized_image():
    # Path to the image
    image_path = "path_to_your_image.jpg"  # Replace this with the actual path to your image

    # Resize the image
    resized_image = resize_image(image_path, 300, 200)

    # Convert the resized image to a Tkinter-compatible format
    tk_image = ImageTk.PhotoImage(resized_image)

    # Set the image to the label
    label.config(image=tk_image)
    label.image = tk_image  # Keeping a reference to avoid garbage collection

# Create the main window
root = tk.Tk()
root.title("Resized Image Example")

# Create a label to display the image
label = tk.Label(root)
label.pack(pady=10)

# Create a button to show the resized image
button = tk.Button(root, text="Show Resized Image", command=show_resized_image)
button.pack(pady=5)

# Run the Tkinter event loop
root.mainloop()
