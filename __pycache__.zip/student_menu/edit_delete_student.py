import tkinter as tk
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox
import student_menu.edit_student as es

class EditDeleteStudent:
    def __init__(self, master,header_frame, display_frame, teacher_id):
        self.teacher_id = teacher_id
        self.master = master
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.checkbox_vars_edit_delete_list = []
        print("inside editdelete teacher menu")
        
        self.students=db.edit_delete_student(self.teacher_id)
        
        if len(self.students)!=0:
            self.lbl_header=tk.Label(self.header_frame,text='Edit / Delete Student Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 1)
            self.create_table()
        else:
            messagebox.showerror('Registration','You havent added any students, please add students!')
    
    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def create_table(self):        
        column_headers = ["First Name          ", "Last Name          ", "User Name          ","Edit/Delete"]
        for col, header in enumerate(column_headers):
            label = tk.Label(self.display_frame, text=header, borderwidth=1, font=('Arial',20),bg='Cyan4',fg='White')
            label.grid(row=0, column=col,sticky = 'W', pady = 2)
        
        for row, data_row in enumerate(self.students, start=1):
            print("in enumerating rows.....................")
            print("printing row number")
            print(row)
            for col, cell_value in enumerate(data_row):
                label = tk.Label(self.display_frame, text=cell_value, borderwidth=2, relief="ridge", font=('Arial',20),bg='Cyan4',fg='White')
                label.grid(row=row, column=col,sticky = 'W', pady = 2)
            checkbox_var = tk.BooleanVar(value=False)
            checkbox = tk.Checkbutton(self.display_frame, variable=checkbox_var,command=lambda myrow=row: self.clear_other_checkboxes(myrow, self.checkbox_vars_edit_delete_list))
            checkbox.grid(row=row, column=3) 
            self.checkbox_vars_edit_delete_list.append(checkbox_var)              

        self.btn_edit=tk.Button(self.display_frame,text='Edit',bg='cyan3',font=('Arial',15), command=self.edit_student_screen)
        self.btn_edit.grid(row=len(self.students)+1,column=1, pady = (20,200))
        self.btn_delete=tk.Button(self.display_frame,text='Delete',bg='cyan3',font=('Arial',15), command=self.delete_student_screen)
        self.btn_delete.grid(row=len(self.students)+1,column=2, pady = (20,200))    
        
    def edit_student_screen(self):
        print("edit student")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for editing")
        else:
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
            es.EditStudent(self.master,self.header_frame,self.display_frame,self.teacher_id,self.students[row_selected][2])

    def delete_student_screen(self):
        print("delete student")
        row_selected = -1
        for i, checkbox in enumerate(self.checkbox_vars_edit_delete_list):
            #print(i,checkbox)
            if checkbox.get()==True:
                row_selected = i
        print(row_selected)
        print(self.students[row_selected])
        print(self.students[row_selected][2])
        if row_selected ==  -1:
            messagebox.showerror("Student Details", "Please select a row for deleting")
        else:
            db.delete_student(self.students[row_selected][2],self.teacher_id)
            messagebox.showinfo('Edit/Delete Student','You have successfully deleted the student!')
            self.clear_frame(self.display_frame)
            self.clear_frame(self.header_frame)

    def clear_other_checkboxes(self,row, checkbox_list):
        for i, checkbox in enumerate(checkbox_list):
            if i+1 != row:
                checkbox.set(False)
    