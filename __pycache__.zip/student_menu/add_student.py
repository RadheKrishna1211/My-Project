import tkinter as tk
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox

class AddStudent:
    def __init__(self, master,header_frame,display_frame,teacher_id):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        
        print("inside add student")
        
        self.lbl_header=tk.Label(self.header_frame,text='Add Student Details',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 20)

        self.lbl_first_name=tk.Label(self.display_frame,text='First Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_first_name.grid(row=1,column=0,sticky = 'W', pady = 20)

        self.lbl_last_name=tk.Label(self.display_frame,text='Last Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_last_name.grid(row=2,column=0,sticky = 'W', pady = 20)

        self.lbl_user_name=tk.Label(self.display_frame,text='User Name :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_user_name.grid(row=3,column=0,sticky = 'W', pady = 20)
        
        self.lbl_password=tk.Label(self.display_frame,text='Password :',font=('Arial',20),bg='Cyan4',fg='White')
        self.lbl_password.grid(row=4,column=0,sticky = 'W', pady = 20)

        self.txtbox_first_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_first_name.grid(row=1,column=2,sticky = 'W', pady = 20)

        self.txtbox_last_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_last_name.grid(row=2,column=2,sticky = 'W', pady = 20)

        self.txtbox_user_name=tk.Entry(self.display_frame,font=('Arial',20))
        self.txtbox_user_name.grid(row=3,column=2,sticky = 'W', pady = 20)

        self.txtbox_password=tk.Entry(self.display_frame, font=('Arial',20),show="*")
        self.txtbox_password.grid(row=4,column=2,sticky = 'W', pady = 20)
    
        self.btn_cancel=tk.Button(self.display_frame,text='Cancel',font=('Arial',15),bg='cyan3',command=self.cancel_command)
        self.btn_cancel.grid(row=5,column=1, pady = (20,200))

        self.btn_submit=tk.Button(self.display_frame,text='Submit',bg='cyan3',font=('Arial',15), command=self.register_student_screen)
        self.btn_submit.grid(row=5,column=2, pady = (20,200))

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def register_student_screen(self):
        user_name=self.txtbox_user_name.get()
        password=self.txtbox_password.get()
        first_name = self.txtbox_first_name.get()
        last_name = self.txtbox_last_name.get() 
        student_object = student.Student(first_name,last_name,user_name,pe.encrypt_password(password),self.teacher_id)
        print("teacher id...",self.teacher_id)
        result = db.check_student_exists(user_name, self.teacher_id)
        if user_name=='' or password=='' or first_name=='' or last_name=='' :
            messagebox.showerror('Registration','Blanks are not allowed')
        elif  result == True:
            messagebox.showerror('Registration','User Name is already taken, select another user name')
        else:
            self.insert_student(student_object)
           

    def insert_student(self,student_object):
        is_student_exists = db.check_student_exists(student_object.user_name,self.teacher_id)
        if not(is_student_exists):
            db.insert_student(student_object)
            messagebox.showinfo('Registration','Student Registered Successfully!!')
            self.clear_frame(self.display_frame)
            self.clear_frame(self.header_frame)
        else:
           messagebox.showerror('Registration','Student User Name Already Exists, give another user name!!')
        
      
    def cancel_command(self):
        self.clear_frame(self.display_frame)
        self.clear_frame(self.header_frame)