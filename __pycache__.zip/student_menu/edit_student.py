import tkinter as tk
import database_code as db
import class_representations.student as student
import password_encryption as pe
from tkinter import messagebox

class EditStudent:
    def __init__(self, master,header_frame,display_frame,teacher_id,student_user_name):
        self.teacher_id = teacher_id
        self.header_frame = header_frame
        self.display_frame=display_frame
        self.master = master
        self.student_user_name = student_user_name
        
        student = db.check_student_exists(student_user_name,teacher_id)
        print("student fetched in editing")
        print(student)
        if student:
            print("inside add student")
            
            self.lbl_header=tk.Label(self.header_frame,text='Edit Student Details',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_header.grid(row=0,column=0,sticky = 'W', pady = 20)

            self.lbl_first_name=tk.Label(self.display_frame,text='First Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_first_name.grid(row=1,column=0,sticky = 'W', pady = 20)

            self.lbl_last_name=tk.Label(self.display_frame,text='Last Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_last_name.grid(row=2,column=0,sticky = 'W', pady = 20)

            self.lbl_user_name=tk.Label(self.display_frame,text='User Name :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_user_name.grid(row=3,column=0,sticky = 'W', pady = 20)
            
            self.lbl_password=tk.Label(self.display_frame,text='Password :',font=('Arial',20),bg='Cyan4',fg='White')
            self.lbl_password.grid(row=4,column=0,sticky = 'W', pady = 20)

            self.txtbox_first_name=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_first_name.grid(row=1,column=2,sticky = 'W', pady = 20)
            print("first data..........")
            print(student[0][1])
            self.txtbox_first_name.insert(0,student[0][1])

            self.txtbox_last_name=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_last_name.grid(row=2,column=2,sticky = 'W', pady = 20)
            self.txtbox_last_name.insert(0,student[0][2])

            self.txtbox_user_name=tk.Entry(self.display_frame,font=('Arial',20))
            self.txtbox_user_name.grid(row=3,column=2,sticky = 'W', pady = 20)
            self.txtbox_user_name.configure(state="normal")
            self.txtbox_user_name.insert(0,student[0][3])
            self.txtbox_user_name.config(state='disabled')
           
            self.txtbox_password=tk.Entry(self.display_frame, font=('Arial',20),show="*")
            self.txtbox_password.grid(row=4,column=2,sticky = 'W', pady = 20)
            self.txtbox_password.insert(0,student[0][4])

            self.btn_submit=tk.Button(self.display_frame,text='Submit',bg='cyan3',font=('Arial',15), command=self.update_student_data)
            self.btn_submit.grid(row=5,column=2, pady = (20,100))

    def clear_frame(self,frame):
        for widgets in frame.winfo_children():
            widgets.destroy()

    def update_student_data(self):
        user_name=self.student_user_name
        password=self.txtbox_password.get()
        first_name = self.txtbox_first_name.get()
        last_name = self.txtbox_last_name.get() 
        student_object = student.Student(first_name,last_name,user_name,pe.encrypt_password(password),self.teacher_id)
        if password=='' or first_name=='' or last_name=='' :
            messagebox.showerror('Student Updation','Blanks are not allowed')
        else:
            self.update_student(student_object)
            self.clear_frame(self.header_frame)
            self.clear_frame(self.display_frame)
           
    def update_student(self, student_object):
        db.update_student(student_object)
        messagebox.showinfo('Student Updation','Student Updated Successfully!!')
  

